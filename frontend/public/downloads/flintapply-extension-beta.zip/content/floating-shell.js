(function(){"use strict";const N="data-flint-click-isolated",P="data-flint-click-guard-installed",H="[data-flint-autofill-overlay], [data-flint-floating-shell]";function re(e){return(typeof e.composedPath=="function"?e.composedPath():[e.target]).some(n=>n instanceof Element&&(n.matches(H)||!!n.closest(H)))}function se(){if(document.documentElement.hasAttribute(P))return;document.documentElement.setAttribute(P,"1");const e=t=>{re(t)&&t.stopImmediatePropagation()};for(const t of["pointerdown","mousedown","mouseup","click"])document.addEventListener(t,e,!1)}function O(e,t){if(e.hasAttribute(N))return;e.setAttribute(N,"1");const n=i=>{i.stopPropagation()};for(const i of["pointerdown","mousedown","mouseup","click"])e.addEventListener(i,n,!1),t?.addEventListener(i,n,!1)}const ae=6e3;function I(e,t,n=ae){const i={count:0},o=r=>{i.count>=n||(i.count+=1,t(r))};if(e instanceof Document){e.body&&g(e.body,o,i,n);return}if(e instanceof Element){g(e,o,i,n);return}for(const r of Array.from(e.children))g(r,o,i,n)}function g(e,t,n,i){if(!(n.count>=i)){t(e),e.shadowRoot&&I(e.shadowRoot,t,i-n.count);for(const o of Array.from(e.children)){if(n.count>=i)return;g(o,t,n,i)}}}const le=200,w=/Posted\s*(?:[·•]\s*)?(?:\d+\s*(?:minute|hour|day|week|month)s?\s+ago|today|yesterday|\d+\s+\w+\s+ago)/i,ce=[/Who you are/i,/What you get to do/i,/What you bring to the role/i,/Responsibilities/i,/Qualifications/i,/Requirements/i,/you will/i,/we are looking/i,/About the role/i,/Do work that matters/i];function _(e){return e.toLowerCase()==="my.greenhouse.io"}function D(e){const t=e.trim();return t?/^my\s*greenhouse$/i.test(t)||/^greenhouse$/i.test(t):!1}function E(e){return(e.innerText??e.textContent??"").trim()}function A(e){const t=e.getBoundingClientRect();if(t.width<40||t.height<24)return!1;const n=window.getComputedStyle(e);return n.display!=="none"&&n.visibility!=="hidden"&&Number(n.opacity)>0}function W(e){return ce.filter(t=>t.test(e)).length}function U(e){return e.toLowerCase().replace(/\s+/g," ").trim()}function y(e,t){const n=U(t);return!n||n.length<3?!1:U(e).includes(n)}function de(e){if(e.getAttribute("aria-selected")==="true"||e.getAttribute("aria-current")==="true"||e.getAttribute("data-selected")==="true")return!0;const t=e.getAttribute("data-state");if(t==="active"||t==="checked"||t==="on")return!0;const n=typeof e.className=="string"?e.className:"";if(/selected|active|highlighted|current|focused/i.test(n))return!0;try{if(e.matches(":focus-within"))return!0}catch{}return!1}function S(e){return e.length>=900||!w.test(e)||e.split(w).slice(1).join(" ").trim().length>=160?!1:e.split(/\n+/).map(i=>i.trim()).filter(Boolean).length<=12}function B(e){const t=e.split(/\n+/).map(s=>s.trim()).filter(Boolean),n=t.findIndex(s=>w.test(s)),i=n>0?t.slice(0,n):t.slice(0,4),o=i[0]??"",r=i[1]??"";return{title:D(o)?"":o,company:D(r)?"":r}}function G(e,t){const n=[],i=new Set,o=[];I(e,s=>{s.matches("button, a, li, div, article, [role='button'], [role='option'], [role='listitem']")&&o.push(s)});const r=window.innerWidth||e.documentElement.clientWidth||1200;for(const s of o){if(t&&!A(s)||s.getBoundingClientRect().left>=r*.45)continue;const h=E(s);if(!S(h))continue;const{title:c,company:d}=B(h);if(!c||!d)continue;let u=!1;for(const Ie of s.children){const ie=E(Ie);if(!S(ie))continue;const oe=B(ie);if(oe.title&&oe.company){u=!0;break}}if(u)continue;const ne=`${c}|${d}`;i.has(ne)||(i.add(ne),n.push({element:s,title:c,company:d}))}return n}function ue(e){const t=G(e,!0);return t.length>0?t:G(e,!1)}function fe(e){const t=ue(e);for(const i of t)if(de(i.element)||i.element.querySelector("[aria-selected='true'], [aria-current='true'], [data-selected='true']"))return i;const n=e.activeElement;if(n&&n!==e.body){for(const i of t)if(i.element===n||i.element.contains(n)||n.contains(i.element))return i}return null}function he(e,t,n){if(S(t))return-1e4;let i=t.length;i+=W(t)*400,n&&(y(t,n.title)&&(i+=5e3),y(t,n.company)&&(i+=2500));const o=e.getBoundingClientRect(),r=window.innerWidth||1200;return o.left>=r*.3&&(i+=800),t.length>=500&&(i+=1e3),i}function pe(e){const t=window.innerWidth||e.documentElement.clientWidth||1200;let n=null;for(const i of e.querySelectorAll("main, main div, [role='main'], #app, #app div, body > div")){if(!A(i)||i.getBoundingClientRect().left<t*.25)continue;const r=E(i);r.length<300||(!n||r.length>n.len)&&(n={el:i,len:r.length})}return n?.el??null}function me(e,t=fe(e)){const n=window.innerWidth||e.documentElement.clientWidth||1200;let i=null;for(const o of e.querySelectorAll("main, main div, main article, main section, [role='main'] div, #app div, [class*='job'] div, [class*='Job'] div")){if(!A(o)||o.getBoundingClientRect().left<n*.2)continue;const s=E(o);if(s.length<le||s.length>4e4||/HomeProfileApplications|Dream Job/i.test(s.slice(0,220)))continue;if(t){if(!y(s,t.title)&&!y(s,t.company))continue}else if(W(s)<1&&!w.test(s))continue;const l=he(o,s,t);(!i||l>i.score)&&(i={el:o,score:l})}return i&&i.score>0?i.el:pe(e)}const z="data-flint-mgh-ui-reparent",be="[data-flint-autofill-overlay], [data-flint-floating-shell]";function F(e=document){if(!_(window.location.hostname))return null;const t=me(e);return t instanceof HTMLElement?t:null}function k(e){const t=F();return t?(e.parentElement===t||(e.dataset.insideMyGreenhousePanel="1",t.appendChild(e)),!0):!1}function J(e=document){if(!_(window.location.hostname))return;const t=F(e);if(t)for(const n of e.querySelectorAll(be))n instanceof HTMLElement&&n.parentElement!==t&&(n.dataset.insideMyGreenhousePanel="1",t.appendChild(n))}function ge(){if(!_(window.location.hostname)||document.documentElement.hasAttribute(z))return;document.documentElement.setAttribute(z,"1");let e=null;const t=()=>{e&&clearTimeout(e),e=setTimeout(()=>{e=null,J()},120)};J(),t();const n=new MutationObserver(t),i=()=>{document.body&&n.observe(document.body,{childList:!0,subtree:!0})};document.body?i():document.addEventListener("DOMContentLoaded",i,{once:!0})}const b="Flint Apply",we="brand/wordmark-light-256.png";function Ee(){return typeof chrome<"u"&&chrome.runtime?.getURL?chrome.runtime.getURL(we):"/brand/wordmark-light-256.png"}function f(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}function ye(e){if(!(e instanceof Error))return!1;const t=e.message.toLowerCase();return t.includes("extension context invalidated")||t.includes("context invalidated")}function p(e){e.catch(t=>{ye(t)||console.error("[FlintApply]",t)})}const xe="FLINT_MYGH_JOB_CHANGED",ve="flint-content",C="flint_fab_hide_global",x="flint_fab_snooze_until",T="flint_fab_hide_hosts_session",Le=24*60*60*1e3;function v(e){return e.trim().toLowerCase()}async function $(){if(!f())return[];try{const t=(await chrome.storage.session.get(T))[T];return Array.isArray(t)?t.filter(n=>typeof n=="string").map(v):[]}catch{return[]}}async function _e(e){if(f())try{await chrome.storage.session.set({[T]:e})}catch{}}async function Ae(e){if(!f())return"none";const t=v(e);try{const n=await chrome.storage.local.get([C,x]);if(n[C]===!0)return"global";const i=n[x];return typeof i=="number"&&i>Date.now()?"snooze":(typeof i=="number"&&i<=Date.now()&&await chrome.storage.local.remove(x),(await $()).includes(t)?"site_session":"none")}catch{return"none"}}async function Se(e){return await Ae(e)==="none"}async function Fe(e){const t=v(e),n=await $();n.includes(t)||(n.push(t),await _e(n))}async function ke(){await chrome.storage.local.set({[x]:Date.now()+Le})}async function Ce(){await chrome.storage.local.set({[C]:!0})}function j(){return v(window.location.hostname)}const m="flint_floating_panel_expanded";function q(){return typeof chrome<"u"&&chrome.storage&&"session"in chrome.storage?chrome.storage.session:null}async function Te(){if(!f())return!1;const e=q();if(e)try{const n=(await e.get(m))[m];if(typeof n=="boolean")return n}catch{}try{return(await chrome.storage.local.get(m))[m]===!0}catch{return!1}}async function Y(e){if(!f())return;const t=q();if(t)try{await t.set({[m]:e});return}catch{}try{await chrome.storage.local.set({[m]:e})}catch{}}const K="data-flint-floating-shell",M="data-flint-floating-listeners",Me="FLINT_FLOATING_COLLAPSE",Re=360;let a=null;const Ne=`
  :host {
    all: initial;
    display: block;
    position: fixed;
    bottom: 0;
    right: 0;
    width: 0;
    height: 0;
    overflow: visible;
    z-index: 2147483647;
    pointer-events: none;
  }
  .fab,
  .drawer,
  .fab-wrap {
    pointer-events: auto;
  }
  .fab-wrap {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 56px;
    height: 56px;
    z-index: 2147483647;
  }
  .fab-wrap[hidden] {
    display: none;
  }
  .fab {
    position: absolute;
    inset: 0;
    width: 56px;
    height: 56px;
    border-radius: 50%;
    background: #0f766e;
    border: none;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.28);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    padding: 0;
  }
  .fab:hover {
    background: #115e59;
  }
  .fab-dismiss {
    position: absolute;
    top: -4px;
    right: -4px;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    border: 2px solid #ffffff;
    background: #334155;
    color: #ffffff;
    font-size: 14px;
    line-height: 1;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    box-shadow: 0 2px 8px rgba(15, 23, 42, 0.25);
  }
  .fab-dismiss:hover {
    background: #1e293b;
  }
  .fab-menu {
    position: absolute;
    bottom: calc(100% + 10px);
    right: 0;
    width: 248px;
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 12px 32px rgba(15, 23, 42, 0.22);
    border: 1px solid #e2e8f0;
    padding: 8px;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .fab-menu[hidden] {
    display: none;
  }
  .fab-menu-title {
    font-size: 12px;
    font-weight: 600;
    color: #475569;
    padding: 4px 8px 6px;
  }
  .fab-menu button {
    border: none;
    background: transparent;
    text-align: left;
    font-size: 13px;
    color: #0f172a;
    padding: 8px 10px;
    border-radius: 8px;
    cursor: pointer;
    font-family: inherit;
  }
  .fab-menu button:hover {
    background: #f1f5f9;
  }
  .fab img {
    width: 28px;
    height: 28px;
    display: block;
    pointer-events: none;
  }
  .drawer {
    position: fixed;
    top: 24px;
    bottom: 24px;
    right: 20px;
    width: ${Re}px;
    max-width: calc(100vw - 32px);
    max-height: calc(100vh - 48px);
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 20px 48px rgba(15, 23, 42, 0.28);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    z-index: 2147483647;
    font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  }
  .drawer[hidden] {
    display: none;
  }
  .drawer-header {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px 44px 16px 16px;
    border-bottom: 1px solid #e2e8f0;
    background: #f8fafc;
    flex-shrink: 0;
  }
  .drawer-title {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
  }
  .drawer-wordmark {
    height: 48px;
    width: auto;
    max-width: calc(100% - 8px);
    object-fit: contain;
    display: block;
  }
  .drawer-close {
    position: absolute;
    top: 50%;
    right: 8px;
    transform: translateY(-50%);
    border: none;
    background: transparent;
    color: #64748b;
    font-size: 18px;
    line-height: 1;
    cursor: pointer;
    padding: 4px 8px;
    border-radius: 6px;
  }
  .drawer-close:hover {
    background: #e2e8f0;
  }
  .drawer-frame {
    flex: 1;
    border: none;
    width: 100%;
  }
`;function X(e){a?.handleOutsideClick(e)}function V(e){e.key==="Escape"&&a?.handleEscape()}function Q(e){a?.handleFrameMessage(e)}function Z(e){if(e.source!==window)return;const t=e.data;t?.type===xe&&t?.source===ve&&a?.handleMyGreenhouseJobChanged()}function ee(){document.documentElement.hasAttribute(M)||(document.documentElement.setAttribute(M,"1"),document.addEventListener("click",X,!0),document.addEventListener("keydown",V),window.addEventListener("message",Q),window.addEventListener("message",Z))}let te=!1;function Pe(){te||(te=!0,chrome.storage.onChanged.addListener(()=>{f()&&p(a?.refreshFabVisibility()??Promise.resolve())}))}function He(){document.removeEventListener("click",X,!0),document.removeEventListener("keydown",V),window.removeEventListener("message",Q),window.removeEventListener("message",Z),document.documentElement.removeAttribute(M)}class Oe{host=null;shadow=null;fabWrap=null;fabMenuEl=null;drawerEl=null;frameEl=null;expanded=!1;pendingJobRefresh=!1;mount(t=document.body){if(this.host){a=this,k(this.host);return}const n=document.querySelector(`[${K}]`);if(n instanceof HTMLElement&&n.shadowRoot){this.host=n,this.shadow=n.shadowRoot,this.fabWrap=this.shadow.querySelector(".fab-wrap"),this.fabMenuEl=this.shadow.querySelector(".fab-menu"),this.drawerEl=this.shadow.querySelector(".drawer"),this.frameEl=this.shadow.querySelector(".drawer-frame"),this.expanded=!!(this.drawerEl&&!this.drawerEl.hidden),O(n,n.shadowRoot??void 0),k(n),a=this,ee(),p(this.refreshFabVisibility());return}this.host=document.createElement("div"),this.host.setAttribute(K,"true"),this.shadow=this.host.attachShadow({mode:"open"}),O(this.host,this.shadow);const i=document.createElement("style");i.textContent=Ne,this.shadow.appendChild(i);const o=this.buildFabUi();this.fabWrap=o.wrap,this.fabMenuEl=o.menu,this.drawerEl=this.buildDrawer(),this.shadow.append(this.fabWrap,this.drawerEl),(F()??t).appendChild(this.host),k(this.host),a=this,ee(),Pe(),p(this.refreshFabVisibility())}getHost(){return this.host}isExpanded(){return this.expanded}expand(){this.host||this.mount(),a=this,this.expanded=!0,this.drawerEl&&(this.drawerEl.hidden=!1),this.fabWrap&&(this.fabWrap.hidden=!0),p(Y(!0)),this.pendingJobRefresh&&(this.reloadPanelFrame("job-changed"),this.pendingJobRefresh=!1)}reloadPanelFrame(t){if(!this.frameEl)return;const n=`${chrome.runtime.getURL("popup/index.html")}?flint=${Date.now()}`;this.frameEl.src=n}handleMyGreenhouseJobChanged(){this.pendingJobRefresh=!0,this.expanded&&this.collapse()}collapse(){this.expanded=!1,this.drawerEl&&(this.drawerEl.hidden=!0),p(Y(!1)),p(this.refreshFabVisibility())}toggle(){this.expanded?this.collapse():this.expand()}async restorePersistedState(){await Te()&&(this.host||this.mount(),a=this,this.expanded=!0,this.drawerEl&&(this.drawerEl.hidden=!1),this.fabWrap&&(this.fabWrap.hidden=!0),this.reloadPanelFrame("session-restore"))}async refreshFabVisibility(){if(!f()||!this.fabWrap||!this.host?.isConnected)return;if(this.expanded){this.fabWrap.hidden=!0,this.closeFabMenu();return}let t=!0;try{t=await Se(j())}catch{return}!this.fabWrap||!this.host?.isConnected||(this.fabWrap.hidden=!t,t||this.closeFabMenu())}handleOutsideClick(t){this.host&&(t.composedPath().includes(this.host)||(this.closeFabMenu(),this.expanded&&this.collapse()))}handleEscape(){this.expanded&&this.collapse()}handleFrameMessage(t){if(!this.expanded||!this.frameEl||t.source!==this.frameEl.contentWindow)return;const n=t.data;!n||n.type!==Me||this.collapse()}destroy(){a===this&&(a=null,He()),this.host?.remove(),this.host=null,this.shadow=null,this.fabWrap=null,this.fabMenuEl=null,this.drawerEl=null,this.frameEl=null,this.expanded=!1}closeFabMenu(){this.fabMenuEl&&(this.fabMenuEl.hidden=!0)}toggleFabMenu(){this.fabMenuEl&&(this.fabMenuEl.hidden=!this.fabMenuEl.hidden)}async applyFabHide(t){const n=j();t==="site_session"?await Fe(n):t==="snooze"?await ke():await Ce(),this.closeFabMenu(),this.expanded&&this.collapse(),await this.refreshFabVisibility()}buildFabUi(){const t=document.createElement("div");t.className="fab-wrap";const n=document.createElement("button");n.type="button",n.className="fab",n.setAttribute("aria-label",`Open ${b}`);const i=document.createElement("img");i.src=chrome.runtime.getURL("icons/icon48.png"),i.alt=b,n.appendChild(i),n.addEventListener("click",u=>{u.preventDefault(),u.stopPropagation(),this.closeFabMenu(),this.expand()},!0);const o=document.createElement("button");o.type="button",o.className="fab-dismiss",o.setAttribute("aria-label",`Hide ${b} button`),o.textContent="×",o.addEventListener("click",u=>{u.preventDefault(),u.stopPropagation(),this.toggleFabMenu()},!0);const r=document.createElement("div");r.className="fab-menu",r.hidden=!0;const s=document.createElement("p");s.className="fab-menu-title",s.textContent="Hide floating button";const l=document.createElement("button");l.type="button",l.textContent="On this site until I close the browser",l.addEventListener("click",()=>void this.applyFabHide("site_session"));const h=document.createElement("button");h.type="button",h.textContent="On all sites for 24 hours",h.addEventListener("click",()=>void this.applyFabHide("snooze"));const c=document.createElement("button");c.type="button",c.textContent="On all sites until I turn it back on",c.addEventListener("click",()=>void this.applyFabHide("global"));const d=document.createElement("button");return d.type="button",d.textContent="Cancel",d.addEventListener("click",()=>this.closeFabMenu()),r.append(s,l,h,c,d),t.append(n,o,r),{wrap:t,button:n,menu:r}}buildDrawer(){const t=document.createElement("div");t.className="drawer",t.hidden=!0;const n=document.createElement("div");n.className="drawer-header";const i=document.createElement("div");i.className="drawer-title";const o=document.createElement("img");o.className="drawer-wordmark",o.src=Ee(),o.alt="",i.append(o);const r=document.createElement("button");return r.type="button",r.className="drawer-close",r.setAttribute("aria-label",`Close ${b} panel`),r.textContent="×",r.addEventListener("click",()=>this.collapse()),n.append(i,r),this.frameEl=document.createElement("iframe"),this.frameEl.className="drawer-frame",this.frameEl.src=chrome.runtime.getURL("popup/index.html"),this.frameEl.title=b,t.append(n,this.frameEl),t}}se(),ge();let L=null;function R(){return L||(L=new Oe,L.mount()),L}window.__flintFloatingShellStarted?R().expand():(window.__flintFloatingShellStarted=!0,R().restorePersistedState().catch(()=>{}),chrome.runtime.onMessage.addListener((e,t,n)=>(typeof e!="object"||e===null||e.type!=="EXPAND_FLOATING_PANEL"||(R().expand(),n({ok:!0})),!1)))})();
