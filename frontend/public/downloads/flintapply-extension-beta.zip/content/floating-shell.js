(function(){"use strict";const T="data-flint-click-isolated",_="data-flint-click-guard-installed",S="[data-flint-autofill-overlay], [data-flint-floating-shell]";function K(e){return(typeof e.composedPath=="function"?e.composedPath():[e.target]).some(n=>n instanceof Element&&(n.matches(S)||!!n.closest(S)))}function Q(){if(document.documentElement.hasAttribute(_))return;document.documentElement.setAttribute(_,"1");const e=t=>{K(t)&&t.stopImmediatePropagation()};for(const t of["pointerdown","mousedown","mouseup","click"])document.addEventListener(t,e,!1)}function k(e,t){if(e.hasAttribute(T))return;e.setAttribute(T,"1");const n=i=>{i.stopPropagation()};for(const i of["pointerdown","mousedown","mouseup","click"])e.addEventListener(i,n,!1),t?.addEventListener(i,n,!1)}const Z=6e3;function R(e,t,n=Z){const i={count:0},o=r=>{i.count>=n||(i.count+=1,t(r))};if(e instanceof Document){e.body&&c(e.body,o,i,n);return}if(e instanceof Element){c(e,o,i,n);return}for(const r of Array.from(e.children))c(r,o,i,n)}function c(e,t,n,i){if(!(n.count>=i)){t(e),e.shadowRoot&&R(e.shadowRoot,t,i-n.count);for(const o of Array.from(e.children)){if(n.count>=i)return;c(o,t,n,i)}}}const V=200,d=/Posted\s*(?:[·•]\s*)?(?:\d+\s*(?:minute|hour|day|week|month)s?\s+ago|today|yesterday|\d+\s+\w+\s+ago)/i,ee=[/Who you are/i,/What you get to do/i,/What you bring to the role/i,/Responsibilities/i,/Qualifications/i,/Requirements/i,/you will/i,/we are looking/i,/About the role/i,/Do work that matters/i];function p(e){return e.toLowerCase()==="my.greenhouse.io"}function C(e){const t=e.trim();return t?/^my\s*greenhouse$/i.test(t)||/^greenhouse$/i.test(t):!1}function u(e){return(e.innerText??e.textContent??"").trim()}function w(e){const t=e.getBoundingClientRect();if(t.width<40||t.height<24)return!1;const n=window.getComputedStyle(e);return n.display!=="none"&&n.visibility!=="hidden"&&Number(n.opacity)>0}function P(e){return ee.filter(t=>t.test(e)).length}function N(e){return e.toLowerCase().replace(/\s+/g," ").trim()}function f(e,t){const n=N(t);return!n||n.length<3?!1:N(e).includes(n)}function te(e){if(e.getAttribute("aria-selected")==="true"||e.getAttribute("aria-current")==="true"||e.getAttribute("data-selected")==="true")return!0;const t=e.getAttribute("data-state");if(t==="active"||t==="checked"||t==="on")return!0;const n=typeof e.className=="string"?e.className:"";if(/selected|active|highlighted|current|focused/i.test(n))return!0;try{if(e.matches(":focus-within"))return!0}catch{}return!1}function g(e){return e.length>=900||!d.test(e)||e.split(d).slice(1).join(" ").trim().length>=160?!1:e.split(/\n+/).map(i=>i.trim()).filter(Boolean).length<=12}function B(e){const t=e.split(/\n+/).map(s=>s.trim()).filter(Boolean),n=t.findIndex(s=>d.test(s)),i=n>0?t.slice(0,n):t.slice(0,4),o=i[0]??"",r=i[1]??"";return{title:C(o)?"":o,company:C(r)?"":r}}function D(e,t){const n=[],i=new Set,o=[];R(e,s=>{s.matches("button, a, li, div, article, [role='button'], [role='option'], [role='listitem']")&&o.push(s)});const r=window.innerWidth||e.documentElement.clientWidth||1200;for(const s of o){if(t&&!w(s)||s.getBoundingClientRect().left>=r*.45)continue;const j=u(s);if(!g(j))continue;const{title:v,company:A}=B(j);if(!v||!A)continue;let q=!1;for(const Ee of s.children){const z=u(Ee);if(!g(z))continue;const X=B(z);if(X.title&&X.company){q=!0;break}}if(q)continue;const Y=`${v}|${A}`;i.has(Y)||(i.add(Y),n.push({element:s,title:v,company:A}))}return n}function ne(e){const t=D(e,!0);return t.length>0?t:D(e,!1)}function ie(e){const t=ne(e);for(const i of t)if(te(i.element)||i.element.querySelector("[aria-selected='true'], [aria-current='true'], [data-selected='true']"))return i;const n=e.activeElement;if(n&&n!==e.body){for(const i of t)if(i.element===n||i.element.contains(n)||n.contains(i.element))return i}return null}function oe(e,t,n){if(g(t))return-1e4;let i=t.length;i+=P(t)*400,n&&(f(t,n.title)&&(i+=5e3),f(t,n.company)&&(i+=2500));const o=e.getBoundingClientRect(),r=window.innerWidth||1200;return o.left>=r*.3&&(i+=800),t.length>=500&&(i+=1e3),i}function re(e){const t=window.innerWidth||e.documentElement.clientWidth||1200;let n=null;for(const i of e.querySelectorAll("main, main div, [role='main'], #app, #app div, body > div")){if(!w(i)||i.getBoundingClientRect().left<t*.25)continue;const r=u(i);r.length<300||(!n||r.length>n.len)&&(n={el:i,len:r.length})}return n?.el??null}function se(e,t=ie(e)){const n=window.innerWidth||e.documentElement.clientWidth||1200;let i=null;for(const o of e.querySelectorAll("main, main div, main article, main section, [role='main'] div, #app div, [class*='job'] div, [class*='Job'] div")){if(!w(o)||o.getBoundingClientRect().left<n*.2)continue;const s=u(o);if(s.length<V||s.length>4e4||/HomeProfileApplications|Dream Job/i.test(s.slice(0,220)))continue;if(t){if(!f(s,t.title)&&!f(s,t.company))continue}else if(P(s)<1&&!d.test(s))continue;const L=oe(o,s,t);(!i||L>i.score)&&(i={el:o,score:L})}return i&&i.score>0?i.el:re(e)}const M="data-flint-mgh-ui-reparent",ae="[data-flint-autofill-overlay], [data-flint-floating-shell]";function b(e=document){if(!p(window.location.hostname))return null;const t=se(e);return t instanceof HTMLElement?t:null}function E(e){const t=b();return t?(e.parentElement===t||(e.dataset.insideMyGreenhousePanel="1",t.appendChild(e)),!0):!1}function I(e=document){if(!p(window.location.hostname))return;const t=b(e);if(t)for(const n of e.querySelectorAll(ae))n instanceof HTMLElement&&n.parentElement!==t&&(n.dataset.insideMyGreenhousePanel="1",t.appendChild(n))}function le(){if(!p(window.location.hostname)||document.documentElement.hasAttribute(M))return;document.documentElement.setAttribute(M,"1");let e=null;const t=()=>{e&&clearTimeout(e),e=setTimeout(()=>{e=null,I()},120)};I(),t();const n=new MutationObserver(t),i=()=>{document.body&&n.observe(document.body,{childList:!0,subtree:!0})};document.body?i():document.addEventListener("DOMContentLoaded",i,{once:!0})}const h="Flint Apply",ce="brand/wordmark-light-256.png";function de(){return typeof chrome<"u"&&chrome.runtime?.getURL?chrome.runtime.getURL(ce):"/brand/wordmark-light-256.png"}const ue="FLINT_MYGH_JOB_CHANGED",fe="flint-content",l="flint_floating_panel_expanded";function F(){return typeof chrome<"u"&&chrome.storage&&"session"in chrome.storage?chrome.storage.session:null}async function he(){const e=F();if(e)try{const n=(await e.get(l))[l];if(typeof n=="boolean")return n}catch{}try{return(await chrome.storage.local.get(l))[l]===!0}catch{return!1}}async function O(e){const t=F();if(t)try{await t.set({[l]:e});return}catch{}try{await chrome.storage.local.set({[l]:e})}catch{}}const U="data-flint-floating-shell",y="data-flint-floating-listeners",me="FLINT_FLOATING_COLLAPSE",pe=360;let a=null;const we=`
  :host {
    all: initial;
    display: block;
    position: fixed;
    bottom: 0;
    right: 0;
    width: 0;
    height: 0;
    overflow: visible;
    z-index: 2147483647;
    pointer-events: none;
  }
  .fab,
  .drawer {
    pointer-events: auto;
  }
  .fab {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 56px;
    height: 56px;
    border-radius: 50%;
    background: #0f766e;
    border: none;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.28);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    padding: 0;
    z-index: 2147483647;
  }
  .fab:hover {
    background: #115e59;
  }
  .fab[hidden] {
    display: none;
  }
  .fab img {
    width: 28px;
    height: 28px;
    display: block;
    pointer-events: none;
  }
  .drawer {
    position: fixed;
    top: 24px;
    bottom: 24px;
    right: 20px;
    width: ${pe}px;
    max-width: calc(100vw - 32px);
    max-height: calc(100vh - 48px);
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 20px 48px rgba(15, 23, 42, 0.28);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    z-index: 2147483647;
    font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  }
  .drawer[hidden] {
    display: none;
  }
  .drawer-header {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px 44px 16px 16px;
    border-bottom: 1px solid #e2e8f0;
    background: #f8fafc;
    flex-shrink: 0;
  }
  .drawer-title {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
  }
  .drawer-wordmark {
    height: 48px;
    width: auto;
    max-width: calc(100% - 8px);
    object-fit: contain;
    display: block;
  }
  .drawer-close {
    position: absolute;
    top: 50%;
    right: 8px;
    transform: translateY(-50%);
    border: none;
    background: transparent;
    color: #64748b;
    font-size: 18px;
    line-height: 1;
    cursor: pointer;
    padding: 4px 8px;
    border-radius: 6px;
  }
  .drawer-close:hover {
    background: #e2e8f0;
  }
  .drawer-frame {
    flex: 1;
    border: none;
    width: 100%;
  }
`;function G(e){a?.handleOutsideClick(e)}function H(e){e.key==="Escape"&&a?.handleEscape()}function W(e){a?.handleFrameMessage(e)}function J(e){if(e.source!==window)return;const t=e.data;t?.type===ue&&t?.source===fe&&a?.handleMyGreenhouseJobChanged()}function $(){document.documentElement.hasAttribute(y)||(document.documentElement.setAttribute(y,"1"),document.addEventListener("click",G,!0),document.addEventListener("keydown",H),window.addEventListener("message",W),window.addEventListener("message",J))}function ge(){document.removeEventListener("click",G,!0),document.removeEventListener("keydown",H),window.removeEventListener("message",W),window.removeEventListener("message",J),document.documentElement.removeAttribute(y)}class be{host=null;shadow=null;fabButton=null;drawerEl=null;frameEl=null;expanded=!1;pendingJobRefresh=!1;mount(t=document.body){if(this.host){a=this,E(this.host);return}const n=document.querySelector(`[${U}]`);if(n instanceof HTMLElement&&n.shadowRoot){this.host=n,this.shadow=n.shadowRoot,this.fabButton=this.shadow.querySelector(".fab"),this.drawerEl=this.shadow.querySelector(".drawer"),this.frameEl=this.shadow.querySelector(".drawer-frame"),this.expanded=!!(this.drawerEl&&!this.drawerEl.hidden),k(n,n.shadowRoot??void 0),E(n),a=this,$();return}this.host=document.createElement("div"),this.host.setAttribute(U,"true"),this.shadow=this.host.attachShadow({mode:"open"}),k(this.host,this.shadow);const i=document.createElement("style");i.textContent=we,this.shadow.appendChild(i),this.fabButton=this.buildFabButton(),this.drawerEl=this.buildDrawer(),this.shadow.append(this.fabButton,this.drawerEl),(b()??t).appendChild(this.host),E(this.host),a=this,$()}getHost(){return this.host}isExpanded(){return this.expanded}expand(){this.host||this.mount(),a=this,this.expanded=!0,this.drawerEl&&(this.drawerEl.hidden=!1),this.fabButton&&(this.fabButton.hidden=!0),O(!0),this.pendingJobRefresh&&(this.reloadPanelFrame("job-changed"),this.pendingJobRefresh=!1)}reloadPanelFrame(t){if(!this.frameEl)return;const n=`${chrome.runtime.getURL("popup/index.html")}?flint=${Date.now()}`;this.frameEl.src=n}handleMyGreenhouseJobChanged(){this.pendingJobRefresh=!0,this.expanded&&this.collapse()}collapse(){this.expanded=!1,this.drawerEl&&(this.drawerEl.hidden=!0),this.fabButton&&(this.fabButton.hidden=!1),O(!1)}toggle(){this.expanded?this.collapse():this.expand()}async restorePersistedState(){await he()&&(this.host||this.mount(),a=this,this.expanded=!0,this.drawerEl&&(this.drawerEl.hidden=!1),this.fabButton&&(this.fabButton.hidden=!0),this.reloadPanelFrame("session-restore"))}handleOutsideClick(t){!this.expanded||!this.host||t.composedPath().includes(this.host)||this.collapse()}handleEscape(){this.expanded&&this.collapse()}handleFrameMessage(t){if(!this.expanded||!this.frameEl||t.source!==this.frameEl.contentWindow)return;const n=t.data;!n||n.type!==me||this.collapse()}destroy(){a===this&&(a=null,ge()),this.host?.remove(),this.host=null,this.shadow=null,this.fabButton=null,this.drawerEl=null,this.frameEl=null,this.expanded=!1}buildFabButton(){const t=document.createElement("button");t.type="button",t.className="fab",t.setAttribute("aria-label",`Open ${h}`);const n=document.createElement("img");n.src=chrome.runtime.getURL("icons/icon48.png"),n.alt=h,t.appendChild(n);const i=()=>{this.expand()};return t.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),i()},!0),t}buildDrawer(){const t=document.createElement("div");t.className="drawer",t.hidden=!0;const n=document.createElement("div");n.className="drawer-header";const i=document.createElement("div");i.className="drawer-title";const o=document.createElement("img");o.className="drawer-wordmark",o.src=de(),o.alt="",i.append(o);const r=document.createElement("button");return r.type="button",r.className="drawer-close",r.setAttribute("aria-label",`Close ${h} panel`),r.textContent="×",r.addEventListener("click",()=>this.collapse()),n.append(i,r),this.frameEl=document.createElement("iframe"),this.frameEl.className="drawer-frame",this.frameEl.src=chrome.runtime.getURL("popup/index.html"),this.frameEl.title=h,t.append(n,this.frameEl),t}}Q(),le();let m=null;function x(){return m||(m=new be,m.mount()),m}window.__flintFloatingShellStarted?x().expand():(window.__flintFloatingShellStarted=!0,x().restorePersistedState().catch(()=>{}),chrome.runtime.onMessage.addListener((e,t,n)=>(typeof e!="object"||e===null||e.type!=="EXPAND_FLOATING_PANEL"||(x().expand(),n({ok:!0})),!1)))})();
